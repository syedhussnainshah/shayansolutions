<template>
    <div class="bg-dark">
        <Navbar />

    </div>
</template>
<script>
import Navbar from '../layouts/Navbar.vue';
export default {
    components: {
        Navbar,
    },
};
</script>

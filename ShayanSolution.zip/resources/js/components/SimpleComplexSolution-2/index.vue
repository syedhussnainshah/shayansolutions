<template>
    <section id="Simple-Solution-For-Complex" style="margin-top: 232px;">
        <div class="container">
            <div class="row d-flex justify-content-center align-items-center">

                <div class="col-md-6">
                    <h6>Lorem ipsum dolor sit ame</h6>
                    <h2>Simple Solution For Complex Connections</h2>
                    <!-- <br> -->
                    <p style="margin-top: 25px;">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed donec gravida feugiat neque, ipsum
                        faucibus. Pharetra vel suspendisse mi odio a velit feugiat sapien.
                    </p>
                    <ul class="p-0 mb-0">
                        <li class="p-0 mb-0">
                            <p class="p-0 mb-0">
                                <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/check-circle.svg"
                                    alt=""> High
                                Analysis
                            </p>
                        </li>
                        <li class="p-0 mb-0">
                            <p class="p-0 mb-0">
                                <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/check-circle.svg"
                                    alt="">
                                Certified Service
                            </p>
                        </li>


                    </ul>
                    <a class="Simple-Solution-Learn-Btn  text-white  mt-3" style="background-color: var(--bg-color);"> Learn
                        More</a>
                </div>
                <div class="col-md-6 d-flex justify-content-center" id="SimpleSolutionFor-img">
                    <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/2.png" alt="">
                </div>

            </div>
        </div>
    </section>
</template>

<template>
    <div>
        <section id="Simple-Solution-For-Complex">
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center">
                    <div class="col-lg-6 d-flex justify-content-center" id="SimpleSolutionFor-img">
                        <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/1.png"
                            alt="">
                    </div>
                    <div class="col-lg-6">
                        <h6 class="p-0 ms-0">Lorem ipsum dolor sit ame</h6>
                        <h2 class="p-0 ms-0">Simple Solutions for Complex Connections
                        </h2>
                        <!-- <br> -->
                        <p style="margin-top: 25px;max-width:  530.626px;color: #05000B;
font-family: Inter;
font-size: 16px;
font-style: normal;
font-weight: 500;
line-height: 160%;" class="p-0 ms-0">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed donec gravida feugiat neque, ipsum
                            faucibus. Pharetra vel suspendisse mi odio a velit feugiat sapien.
                        </p>
                        <ul class="p-0 mb-0">
                            <li class="p-0 mb-0">
                                <p class="p-0 mb-0">
                                    <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/check-circle.svg"
                                        alt=""> High
                                    Analysis
                                </p>
                            </li>
                            <li class="p-0 mb-0">
                                <p class="p-0 mb-0">
                                    <img src="https://shayansolution.toptrendingsite.com/storage/images/simple-solution-for-complex/check-circle.svg"
                                        alt="">
                                    Certified Services
                                </p>
                            </li>


                        </ul>
                        <a class="Simple-Solution-Learn-Btn  text-white  mt-3" style="background-color: var(--bg-color);">
                            Learn More</a>
                    </div>

                </div>
            </div>
        </section>
    </div>
</template>

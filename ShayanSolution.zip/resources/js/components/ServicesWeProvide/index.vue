<template>
    <section id="Services-We-Provide-To-Empower-You">
        <center>
            <h2 id="Services-weprovide-Title" class="mb-3"> <span>Services </span>We Provide To Empower You</h2>
        </center>
        <div class="container ">
            <div class="row p-0 m-0 d-flex justify-content-center  align-items-center">
                <div class="col-md-8 p-0 m-0 text-center ">
                    <p class="mb-0 p-0" style="margin-top: 22px;max-width: 775px;
height: 75px;
flex-shrink: 0;color: #05000B;
text-align: center;
font-family: Inter;
font-size: 16px;
font-style: normal;
font-weight: 500;
line-height: 153.5%; opacity: 0.7;">Shayan Solutions is a renowned software development company in the USA known for
                        its end-to-end approach, dedicated to turning ideas into reality. Their seasoned team offers
                        customized services for rapid user engagement.</p>
                </div>
            </div>
        </div>
        <div class="container d-flex justify-content-center" id="Services-Cad-Content">
            <div class="row   d-flex justify-content-center " style="max-width: 1120px;">
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header p-0 mb-0">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/3.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>UI/UX, <br>
                                Designer </h5>
                            <p>We create user-friendly web, mobile, and software interfaces with a focus on
                                excellent user experiences through user-centric design and SEO.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/2.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>Software <br>
                                Development </h5>
                            <p>We offer customized software development with a focus on performance, security, and
                                scalability for reliable, long-term solutions.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/4.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>Web <br>
                                Development</h5>
                            <p>We create responsive, interactive web solutions using advanced technology for custom
                                websites and applications.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/1.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>Quality <br> Assurance</h5>
                            <p>We help businesses ensure their software meets top quality standards by identifying
                                and fixing issues related to performance, security, and scalability..</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/5.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>AI/ Machine <br>
                                Learning</h5>
                            <p>We craft innovative and user-friendly interfaces for web assets, mobile apps, and
                                various software solutions. </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/7.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>IT <br> Consultancy
                            </h5>
                            <p>We assist businesses in finding and using ideal software solutions for their goals,
                                offering tailored recommendations and real-time technology utilization. </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/6.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>DevOps <br> Assistance</h5>
                            <p>We help businesses improve workflows with best practices and advanced tech for
                                faster, high-quality development and deployment.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3  d-flex justify-content-center">
                    <div class="card p-0 mb-0">
                        <div class="card-header">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/services-we-provide-to-empower-you/8.png"
                                alt="">
                        </div>
                        <div class="card-body">

                            <h5>Blockchain <br> Developer
                            </h5>
                            <p>We focus on creating secure DApps and smart contracts on blockchain with expert
                                developers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<template>
    <section id="Talent-Global">
        <div class="container-fluid" style="min-height: 50vh;">
            <div class="row" style="min-height: 50vh;">
                <div class="col-md-12 d-flex justify-content-center align-items-center">
                    <h1 class="w-50 text-white"><span id="GolbalTalentHeading"> Hire the Top 3% of Freelance</span> <br>
                        Talent Globally
                    </h1>
                </div>
            </div>
        </div>
    </section>
</template>
<style
 scoped
>
#GolbalTalentHeading {
    white-space: nowrap
}

@media screen and (max-width: 768px) {
    #GolbalTalentHeading {
        white-space: pre-wrap
    }
}
</style>


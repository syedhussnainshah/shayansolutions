<template>
    <div>
        <section id="Our-Companies-Trust">
            <center>
                <h2 id="OUR-Global-Companies">Our Global <span>Top-Tier</span> Companies Trust</h2>
            </center>

            <div class="container p-0 mb-0 " id="Our-Companies-Trust-container">
                <div class="row p-0 mb-0 d-flex justify-content-center">
                    <div class="col-md-3 p-0 mb-0 mt-0">
                        <div class="card ">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/6.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3 mt-0">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/7.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3 mt-0">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/3.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3 mt-0">
                        <div class="card ">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/8.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/2.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3 ">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/1.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/4.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3">
                            <img src="https://shayansolution.toptrendingsite.com/storage/images/our-companies-trust/5.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<template>
    <section id="TheBestPart">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>The best part? Everything.</h2>
                    <ul>
                        <li style="padding-right: 130px;">
                            <h5><i class="fa-solid fa-circle-check" style="color: #268FC5
                                    "></i> <span style="margin-left: 8px;">Stick to your budget</span> </h5>
                            <p>Collaborate over projects with your team and clients <br> optimised for mobile and tablet
                                don't let slow</p>
                        </li>
                        <li style="padding-right: 130px;">
                            <h5><i class="fa-solid fa-circle-check" style="color: #268FC5
                                    "></i><span style="margin-left: 8px;"> Get Quality work Quickly</span> </h5>
                            <p>Collaborate over projects with your team and clients <br> optimised for mobile and tablet
                                don't let slow</p>
                        </li>
                        <li style="padding-right: 130px;">
                            <h5><i class="fa-solid fa-circle-check" style="color: #268FC5
                                    "></i><span style="margin-left: 8px;"> Pay when your’e happy </span></h5>
                            <p>Collaborate over projects with your team and clients <br> optimised for mobile and tablet
                                don't let slow</p>
                        </li>
                        <li style="padding-right: 130px;">
                            <h5><i class="fa-solid fa-circle-check" style="color: #268FC5
                                    "></i><span style="margin-left: 8px;"> 24/7 Support </span> </h5>
                            <p>Collaborate over projects with your team and clients <br> optimised for mobile and tablet
                                don't let slow</p>
                        </li>
                    </ul>
                </div>
                <div class="col-md-6 d-flex justify-content-center align-items-center">
                    <iframe width="606" height="387" src="https://www.youtube.com/embed/and6XoS9g4E?si=Pa5NtjECh-Qn49FO"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>
</template>

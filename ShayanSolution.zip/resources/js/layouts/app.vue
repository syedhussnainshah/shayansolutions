<template>
    <div class="wrapper">
        <router-view></router-view>
    </div>
</template>

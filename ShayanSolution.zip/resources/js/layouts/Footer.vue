<template>
    <footer id="Footer" class="p-0 d-flex justify-content-center align-items-center flex-column"
        style="background-color: #0B092D;">
        <div class="container-fluid p-5 " style="min-height: 503px;max-width: 1490px;">
            <div class="container-fluid p-0 ">

                <img src="http://127.0.0.1:8000/storage/images/logo.png" style=" margin-top: 71px;" alt="">
            </div>
            <div class="row  " style="margin-top: 63px;">
                <div class="col-md-4" id="Footer-Col-1">
                    <h2>Stay Connected</h2>
                    <p class="p-0" style="width: 295.487px;
height: 40.539px;">Contact us today to get market competitive quotes and get your project started.</p>

                    <p style="margin-top: 55px;">
                        Subscribe to Shayan Solutions
                    </p>
                    <ul id="SocialIcon">
                        <li>
                            <a href="">
                                <i class="fa-brands fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa-brands fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa-brands fa-youtube"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-2" id="Footer-Col-2">
                    <h5>Who We Are</h5>
                    <ul>
                        <li>
                            <a href="">Company</a>
                        </li>
                        <li>
                            <a href="">Partners</a>
                        </li>
                        <li>
                            <a href="">Blog</a>
                        </li>
                        <li>
                            <a href="">Contact Us</a>
                        </li>

                    </ul>
                </div>
                <div class="col-md-3" id="Footer-Col-2">
                    <h5>Our Services</h5>
                    <ul>
                        <li>
                            <a href="">Hire Android Developer</a>
                        </li>
                        <li>
                            <a href="">Hire iOS Developer</a>
                        </li>
                        <li>
                            <a href="">Hire Full Stack Developer</a>
                        </li>
                        <li>
                            <a href="">Hire QA Tester</a>
                        </li>
                        <li>
                            <a href="">Hire Project Manager</a>

                        </li>
                        <li>
                            <a href="">Hire DevOps Specialist</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3 d-flex justify-content-center align-items-center  ps-0 pe-0">
                    <ul class=" p-0">
                        <li class="">
                            <p style="color: #C0CDF7;
font-family: Inter;
font-size: 22px;
font-style: normal;
font-weight: 300;
line-height: 24px; width: 277px;
height: 72px;
flex-shrink: 0;">Office no 1203, 12th Floor Al Hafeez Executive, 30-C3 Gulberg III, Lahore</p>
                        </li>
                        <li>
                            <p style="color: #C0CDF7;
font-family: Inter;
font-size: 22px;
font-style: normal;
font-weight: 300;
line-height: 24px;white-space: no-wrap; ">US Phone: +1 408 786 5702</p>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid  d-flex justify-content-center align-items-center"
            style="background-color: #0B092D; border-top: 1px solid #636363;min-height: 113px;">
            <div class="row ">
                <div class="col-md-12 ">
                    <p class="text-center  m-0 p-3" style="color: #C0CDF7;">© Copyright Shayan Solutions. All Rights
                        Reserved

                        <span style="color: #8D9DD2;
font-family: Inter;
font-size: 17px;
font-style: normal;
font-weight: 400;
line-height: 24px;margin-left: 73px;">Privacy policy</span>
                    </p>
                </div>
            </div>
        </div>
    </footer>
</template>
